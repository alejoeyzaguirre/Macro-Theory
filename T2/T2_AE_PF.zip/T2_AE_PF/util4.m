function u= util4(c, theta,n)
    %Función CRRA explicitada en el enunciado.
                u= log(c) + theta*log(1-n);
          
end