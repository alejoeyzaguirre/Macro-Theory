function imagen = f1(x)
    imagen = x^3-x+2;
end