function imagen = d2h(t)
    imagen = -9.81;
end