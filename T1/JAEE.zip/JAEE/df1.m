function imagen = df1(x)
    imagen = 3*x^2-1;
end