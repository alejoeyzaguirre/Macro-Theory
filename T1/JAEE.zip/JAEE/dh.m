function imagen = dh(t)
    imagen = 4.5 - 9.81*t;
end