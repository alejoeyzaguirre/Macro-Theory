TAREA 1 Teoría Macroeconómica 
Jose Alejo Eyzaguirre Ercilla

Pasos a seguir:

1.- Abrir archivo .m madre: T1_JAEE.m
2.- Establecer directorio con carpeta completa JAEE.
3.- Ejecutar código.
4.- Disfrutar


Gracias!