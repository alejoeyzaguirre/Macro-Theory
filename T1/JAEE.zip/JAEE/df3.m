function imagen = df3(x)
    imagen = (1/x)+(1/(3*(x^3)))*9*x^2;
end