function imagen = f3(x)
    imagen = log(x)+log(3*(x^3));
end